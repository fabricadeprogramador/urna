# Pure CSS Particle Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/hf666/pen/WVrpWe](https://codepen.io/hf666/pen/WVrpWe).

CSS particle animation without JavaScript. The most important point is random movement of particles. The vignetting was created by mask-image property.