# Horizontal parallax sliding slider  with Swiper.js

A Pen created on CodePen.io. Original URL: [https://codepen.io/digistate/pen/aEqzBB](https://codepen.io/digistate/pen/aEqzBB).

